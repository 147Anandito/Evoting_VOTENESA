import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Voting {

    private JTextField inputNameField;
    private JTextField inputNimField;
    private JTextField inputProdiField;
    private JButton candidate1Button;
    private JButton candidate2Button;
    private JButton viewProfileButton1;
    private JButton viewProfileButton2;
    private JButton cancelButton;
    private JButton saveButton;
    private JLabel candidate1ImageLabel;
    private JLabel candidate2ImageLabel;

    private static final String[] candidates = {
            "Visi:\nMembangun masa depan yang cerah untuk semua mahasiswa.\n\nMisi:\n1. Meningkatkan kualitas pendidikan.\n2. Meningkatkan fasilitas kampus.\n3. Mendukung pengembangan bakat mahasiswa.",
            "Visi:\nMenjadi agen perubahan dalam dunia pendidikan.\n\nMisi:\n1. Meningkatkan kolaborasi dengan industri.\n2. Memperkenalkan program pembelajaran inovatif.\n3. Memastikan keberlanjutan lingkungan kampus."
    };
    private int selectedCandidate;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Voting evotingApp = new Voting();
            evotingApp.createAndShowGUI();
        });
    }

    private void createAndShowGUI() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel titleLabel = new JLabel("VOTE_NESA");
        titleLabel.setFont(new Font("Elephant", Font.ITALIC, 20));
        titleLabel.setBounds(120, 10, 250, 30);
        frame.add(titleLabel);

        JLabel nameLabel = new JLabel("Nama:");
        nameLabel.setBounds(50, 50, 100, 30);
        frame.add(nameLabel);

        inputNameField = new JTextField();
        inputNameField.setBounds(150, 50, 200, 30);
        frame.add(inputNameField);

        JLabel nimLabel = new JLabel("NIM:");
        nimLabel.setBounds(50, 90, 100, 30);
        frame.add(nimLabel);

        inputNimField = new JTextField();
        inputNimField.setBounds(150, 90, 200, 30);
        frame.add(inputNimField);

        JLabel prodiLabel = new JLabel("Program Studi:");
        prodiLabel.setBounds(50, 130, 100, 30);
        frame.add(prodiLabel);

        inputProdiField = new JTextField();
        inputProdiField.setBounds(150, 130, 200, 30);
        frame.add(inputProdiField);

        candidate1Button = new JButton("Calon 1");
        candidate1Button.setBounds(50, 190, 120, 30);
        candidate1Button.addActionListener(new VoteButtonActionListener(0));
        frame.add(candidate1Button);

        candidate2Button = new JButton("Calon 2");
        candidate2Button.setBounds(200, 190, 120, 30);
        candidate2Button.addActionListener(new VoteButtonActionListener(1));
        frame.add(candidate2Button);

        viewProfileButton1 = new JButton("Profil Calon 1");
        viewProfileButton1.setBounds(50, 350, 120, 30);
        viewProfileButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCandidateProfile(0, "Hermawan sudrajat", "Sistem Informasi");
            }
        });
        frame.add(viewProfileButton1);

        viewProfileButton2 = new JButton("Profil Calon 2");
        viewProfileButton2.setBounds(200, 350, 120, 30);
        viewProfileButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCandidateProfile(1, "Riyan babayo", "Teknik Informatika");
            }
        });
        frame.add(viewProfileButton2);

        cancelButton = new JButton("Batal Memilih");
        cancelButton.setBounds(50, 400, 120, 30);
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetForm();
            }
        });
        frame.add(cancelButton);

        saveButton = new JButton("Simpan");
        saveButton.setBounds(200, 400, 120, 30);
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveVote();
            }
        });
        frame.add(saveButton);

        candidate1ImageLabel = new JLabel();
        candidate1ImageLabel.setBounds(60, 230, 100, 100); // Adjust the position and size as needed
        candidate1ImageLabel.setIcon(new ImageIcon("C:\\Users\\Lenovo\\Pictures\\profile.png")); // Replace "path/to/candidate1-icon.png" with the actual path to candidate 1's icon file
        frame.add(candidate1ImageLabel);

        candidate2ImageLabel = new JLabel();
        candidate2ImageLabel.setBounds(210, 230, 100, 100); // Adjust the position and size as needed
        candidate2ImageLabel.setIcon(new ImageIcon("C:\\Users\\Lenovo\\Pictures\\profile.png")); // Replace "path/to/candidate2-icon.png" with the actual path to candidate 2's icon file
        frame.add(candidate2ImageLabel);

        frame.setSize(400, 450);
        frame.setLocationRelativeTo(null); // Center the frame on the screen
        frame.setVisible(true);
    }

    private void showCandidateProfile(int candidateNumber, String candidateName, String candidateProdi) {
        // Show candidate profile in a dialog
        String candidateInfo = candidates[candidateNumber];
        String profileText = "Nama: " + candidateName +
                "\nJurusan: " + candidateProdi +
                "\n\n" + candidateInfo;

        JOptionPane.showMessageDialog(null, profileText, "Profil Calon " + (candidateNumber + 1), JOptionPane.INFORMATION_MESSAGE);
    }

    private void resetForm() {
        inputNameField.setText("");
        inputNimField.setText("");
        inputProdiField.setText("");
        selectedCandidate = -1; // Reset selected candidate
    }

    private void saveVote() {
        if (selectedCandidate == -1) {
            JOptionPane.showMessageDialog(null, "Silakan pilih calon terlebih dahulu.");
        } else {
            String name = inputNameField.getText();
            String nim = inputNimField.getText();
            String prodi = inputProdiField.getText();
            String candidateName = (selectedCandidate == 0) ? "Hermawan sudrajat" : "Riyan babayo";

            // Simpan data pemilih dan calon yang dipilih ke database atau file di sini.
            // Contoh: Database.saveVote(name, nim, prodi, candidateName);

            JOptionPane.showMessageDialog(null, "Vote Berhasil");
        }
    }

    private class VoteButtonActionListener implements ActionListener {
        private int candidateNumber;

        public VoteButtonActionListener(int candidateNumber) {
            this.candidateNumber = candidateNumber;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (selectedCandidate != -1) {
                JOptionPane.showMessageDialog(null, "Maaf, Anda sudah memilih.");
            } else {
                selectedCandidate = candidateNumber;
                String name = inputNameField.getText();
                String nim = inputNimField.getText();
                String prodi = inputProdiField.getText();

                String candidateName = (selectedCandidate == 0) ? "Hermawan sudrajat" : "Riyan babayo";
                JOptionPane.showMessageDialog(null, "Terima kasih, " + name + " (" + nim + ", " + prodi + "), Anda memilih " + candidateName + "!");
            }
        }
    }
}
